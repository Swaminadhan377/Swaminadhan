﻿using System;
public class program
{
    public static void Main(string[] args)
    {
        IList<Student> studentList= new List<string>()
        {

        }
    }
}