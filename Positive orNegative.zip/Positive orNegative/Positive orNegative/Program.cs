﻿using System;
class Program
{
    static void Main(string[] args)
    {
        //    Console.WriteLine("Enter a number");
        //    int n = Convert.ToInt32(Console.ReadLine());
        //    if (n > 0)
        //    {
        //        Console.WriteLine("enter number is positive");
        //    }
        //     else if(n < 0)
        //    {
        //        Console.WriteLine("entered number is negative");
        //    }

        //int a, b;
        //Console.WriteLine("Enetr a number");
        //a=Convert.ToInt32(Console.ReadLine());
        //b =Convert.ToInt32(Console.ReadLine());
        //if (a > b)
        //{
        //    Console.WriteLine("a is greater");
        //}
        //else
        //{
        //    Console.WriteLine("b is greater");
        //}

        //int a, b, c;
        //Console.WriteLine("enter the numbers");
        // a=int.Parse(Console.ReadLine());
        //Console.WriteLine("enter the numbers");
        //b = int.Parse(Console.ReadLine());
        //c = b;
        //a=b;
        //b = c;
        //Console.WriteLine(" after swapping a is :"+a);
        //Console.WriteLine(" after swapping b is:"+b); 

        //Console.WriteLine("Enter a number:");
        //int d=int.Parse(Console.ReadLine());
        //    if (d / 3 == 0)
        //    {
        //        Console.WriteLine("number divisible by 2 ");
        //    }
        //    else
        //    {
        //        Console.WriteLine("number is not divisible by 2");
        //    }

        //int a, b, i, sum = 0;
        //for (i = 0; i < 100; i++)
        //{
        //    a=i%3; 
        //    b=i/5;
        //    if(a==0||a==0)
        //    {
        //        Console.WriteLine("{0}\t",i);
        //        sum = sum + i;
        //    }
        //}
        //Console.WriteLine("The Sum of all the Multiples of 3 or 5 Below 100 :");
        //int a, i;
        //Console.WriteLine("multiples of 17 are:");
        //for (i = 1; i < 100; i++)
        //{
        //    a = i % 17;
        //    if(a == 0)
        //    {
        //        Console.WriteLine(i);
        //    }
        //}
        //Console.ReadLine();


        int a, sum = 0;
        int num = 125;
        string c=Convert.ToString(num);
        for(int i = 0; i < c.Length; i++) 
        
        {
            a = num % 10;
            num=num / 10;
            sum=sum + a;

        }
        Console.WriteLine(sum);
        Console.ReadLine();
    }
}