﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwapTwoNumbers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a=4;
            int b=5;
            int c;
            Console.WriteLine("Before Swapping a is "+a + " :b is " + b);
            c = a;
            a = b;
            b = c;
            Console.WriteLine("after Swapping a is " + a + " :b is " + b);
        }
    }
}
