﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumOfFirstDigit
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("enter a number");
            //int no=int.Parse(Console.ReadLine());
            int no = 7341;
            int r = 0;
            int sum = 0;
            for (int i = 1; i <= 4; i++)
            {
                //if(i==1||i==4)
                if (i == 2 || i == 3)
                {
                    r = no % 10;
                    sum += r;
                }
                no = no / 10;
            }
            Console.WriteLine(sum);
        }
    }
}
//using System;

//class Program
//{
//    static void Main()
//    {
//        Console.Write("Enter the base number (x): ");
//        double x = Convert.ToDouble(Console.ReadLine());

//        Console.Write("Enter the exponent (n): ");
//        int n = Convert.ToInt32(Console.ReadLine());

//        double result = Math.Pow(x, n);
//        Console.WriteLine("{0} raised to the power of {1} is: {2}", x, n, result);
//    }
//}
