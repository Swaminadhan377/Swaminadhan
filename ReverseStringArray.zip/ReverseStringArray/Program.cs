﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReverseStringArray
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string input = "qualitythought";
            char[]chararray = input.ToCharArray();
            Array.Reverse(chararray);
            string reversestring=new string(chararray);
            Console.WriteLine(reversestring);
        }

    }
}
