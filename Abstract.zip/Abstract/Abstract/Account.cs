﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract
{
    internal  abstract class Account
    {
        protected int AccountNO;
        protected string Name;
        protected double Balance;
        public Account(int accuntNO, string name, double balance)
        {
            AccountNO = accuntNO;
            Name = name;
            Balance = balance;
        }   
        public void deposit(double amount)
        {
            Balance += amount;
            Console.WriteLine("enter deposit amount:"+amount);
        }
        public void ShowAccount()
        {
            Console.WriteLine(AccountNO+" "+Name+" "+Balance);
        }
        public abstract void WithDraw(double amount);
    }
}
