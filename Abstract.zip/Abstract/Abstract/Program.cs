﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Account a= new Account();
            Account p;
            Savings customer1=new Savings(1001,"hello",1000);
            customer1.ShowAccount();
            customer1.deposit(200);
            customer1.WithDraw(600);
            customer1.WithDraw(400);
            //Salary employee1 = new Salary(2001, "kiran", 15000);
            //employee1.ShowAccount();
            //employee1.Deposit(2000);
            //employee1.WithDraw(6000);
            Current comp1=new Current(3000,"QT",10000);
            comp1.ShowAccount();
            comp1.deposit(200);
            comp1.WithDraw(600);
            comp1.WithDraw(3000);

            p = customer1;
            Console.WriteLine(p.GetHashCode()+" "+customer1.GetHashCode());
            p.ShowAccount();
            p.deposit(400);
            p.WithDraw(200);

            //p = employee1;
            //Console.WriteLine(p.GetHashCode()+" " +employee1.GetHashCode());
            //p.ShowAccount();
            //p.deposit(1200);
            //p.WithDraw(880);

            p = comp1;
            Console.WriteLine(p.GetHashCode() + " " + customer1.GetHashCode());
            p.ShowAccount();
            p.deposit(2000);
            p.WithDraw(90000);

            Account x = new Salary(2002, "nataraj", 80000);
            x.ShowAccount();
            x.WithDraw(1000);
            x.deposit(2000);

        }
    }
}
