﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract
{
    internal class Current : Account
    {
        public Current(int ano, string anm, double bl) : base(ano, anm, bl)
        {
            //AccountNO = ano;
            //Name=anm;
            //Balance=bl;
        }

        public override void WithDraw(double amount)
        {
            if ((Balance - amount) < 5000)
            {
                Console.WriteLine("Min balance  300 is required:" + amount);
            }
            else
            {
                Balance -= amount;
                Console.WriteLine("balance after withdraw: " + Balance);
            }
        }
    }
}

