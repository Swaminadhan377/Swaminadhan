﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract
{
    internal class Savings:Account
    {
        public Savings(int ano,string anm,double bl) :base(ano,anm,bl) 
        { 
            //AccountNO = ano;
            //Name=anm;
            //Balance=bl;
        }

        public override void WithDraw(double amount)
        {
            if ((Balance - amount) < 300)
            {
                Console.WriteLine("Min balance  300 is required:"+amount);
            }
            else
            {
                Balance -= amount;
                Console.WriteLine("balance after withdraw: " + Balance);
            }
            //throw new NotImplementedException();
        }
    }
}
