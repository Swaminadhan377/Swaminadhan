﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialMethod
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ProductDal dal = new ProductDal();
            dal.AddProduct();
            dal.DeleteProduct();
            
        }
    }
}
