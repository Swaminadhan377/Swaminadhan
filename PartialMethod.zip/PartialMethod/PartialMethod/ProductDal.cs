﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialMethod
{
    internal partial class ProductDal
    {
         partial void Add();
        partial void Delete();
        partial void Find();
        partial void Update();
    }
    partial class ProductDal
    {
         partial void Add()
         {
            // throw new NotImplementedException();
            Console.WriteLine("Programmer 1 provided Add");
         }
        public void AddProduct()
        {
            Add();  
        }
    }
    partial class ProductDal
    {
        partial void Delete()
        {
            ///throw new NotImplementedException();
            Console.WriteLine("Programmer 2 provided Delete");
        }
        public void DeleteProduct()
        {
            Delete();
        }
    }
}
