﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimENumber
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number");
            int no=int.Parse(Console.ReadLine());
            int count = 0;
            for(int i = 1; i <=no; i++)
            {
                if (no % i == 0)
                {
                    count++;
                }
            }
            if(count == 2)
            {
                Console.WriteLine(no+" is prime nummber");
            }
            else 
            {
                Console.WriteLine(no + " is not prime");
                    }
        }
    }
}
