﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Static7th
{
    internal class Bike
    {
        public static int nobs;
       public int Id;
       public string Owner;
        static Bike()
        {
            nobs = 0;
        }
        public Bike (int id,string owner)
        {
             Id = id;
            Owner = owner;
            nobs = nobs + 1;

        }
        public void GetBikeData()
        {
            Console.WriteLine(Id + " " + Owner);
        }
        public  static void ShowNobs()
        {
            Console.WriteLine("static function:"+nobs);
        }

    }
}
