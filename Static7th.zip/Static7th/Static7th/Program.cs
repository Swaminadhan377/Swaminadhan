﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Static7th
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("opening bikes:no of bikes sold:"+Bike.nobs);
            Bike.ShowNobs();

            Bike b1=new Bike(101,"kiran");
            b1.GetBikeData();
            Console.WriteLine(b1.Id+"  "+b1.Owner);
            Console.WriteLine(b1.GetHashCode());
            Console.WriteLine("number of bikes sold:" + Bike.nobs);
            Bike.ShowNobs();

            Bike b2 = new Bike(102, "hemanth");
            b2.GetBikeData();
            Bike.ShowNobs();
        }
    }
}
