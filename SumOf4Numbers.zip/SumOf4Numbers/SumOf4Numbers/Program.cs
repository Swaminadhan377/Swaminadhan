﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumOfNumbers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int no = 1234;
            int sum = 0;
            int r = 0;
            int square=0;
            for (int i = 1; i <= 4; i++)
            {
                r = no % 10;
                square = r * r ;
                sum = sum + square;
                no = no / 10;
            }
                Console.WriteLine(sum);
            Console.ReadKey();
            
        }
    }
}
