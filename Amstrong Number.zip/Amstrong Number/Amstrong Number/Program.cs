﻿using System;
using static System.Runtime.InteropServices.JavaScript.JSType;

class program
{
    public static void Main(System.String[] args)
    {
        int no, rem;
        int  sum = 0;
        
        Console.WriteLine("Enter a number");
        no = int.Parse(Console.ReadLine());
        for (int i = no; i > 0; i = i / 10)
        {
            rem = i % 10;
            sum = sum + rem * rem * rem;

        }
        if (sum == no)
        {
            Console.WriteLine("amstrong number");
        }
        else
        {
            Console.WriteLine("not amstrong number");
        }
    }
    
}